# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'QMS SALE ORDER',
    'category': 'Sales/CRM',
    'summary': '',
    'description': """
This module gives you a quick view of your contacts directory, accessible from your home page.
You can track your vendors, customers and other contacts.
""",
    'depends': ['base', 'contacts', 'sale', 'qms_contact', 'sale_stock'],
    'data': [

        'security/security_views.xml',
        'security/ir.model.access.csv',
        # 'wizard/send_mo_pack_view.xml',
        # 'wizard/xlsx_output_view.xml',
        # 'views/mark_old_mail_template.xml',
        'views/product_view.xml',
        'views/send_mo_fo_packing_mail_temp.xml',
        'views/sample_gift_sequence.xml',
        'views/sale_order_views.xml',
        'views/gift_form_view.xml',
        'views/sale_order_line_view.xml',
        'views/default_packaging_config_view.xml',
        'views/package_design_view.xml',
        # 'views/send_for_design_mail_template.xml',
        # 'views/notify_saleperson_mail_template.xml',
        # 'views/convert_to_gift_mail_template.xml',
        # 'views/send_mail_purchase.xml',
        # 'views/display_order_view.xml',
        # 'views/address_report.xml',
        # 'views/reject_gift_convert_mail_template.xml',
        # 'views/invoice_order_report.xml',
        # 'views/send_for_convert_into_gift.xml',
        # 'views/purchase_requisition_view.xml',
        'views/sale_menus.xml',
        'views/res_users_view.xml',
        'views/res_company_view.xml',
        'views/packaging_views.xml',
        # 'views/customization_email_template.xml',
        # 'views/sample_approval_emails.xml',
        # 'report/order_report.xml',
        # 'report/sample_order_report.xml',
        # 'report/gift_order_report.xml',
        # 'report/report_view.xml',
        # 'report/sale_kit_report.xml',
        # 'report/pro_forma_invoice_report.xml',
        # 'views/account_invoice_view.xml',
    ],
    'application': True,
}
