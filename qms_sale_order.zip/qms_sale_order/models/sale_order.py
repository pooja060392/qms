from odoo.exceptions import UserError, AccessError, ValidationError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from collections import defaultdict
from datetime import datetime
from dateutil.relativedelta import relativedelta
from odoo.tools.misc import split_every
from psycopg2 import OperationalError
from odoo import api, fields, models, registry, _
from odoo.osv import expression
from datetime import timedelta
import odoo.addons.decimal_precision as dp
from num2words import num2words
from datetime import datetime, timedelta, date
import calendar
from lxml import etree


class SaleOrder(models.Model):
    _inherit = 'sale.order'
    _order = "date_order desc"

    amount_to_text = fields.Text(string='In Words',
                                 store=True, readonly=True, compute='_amount_in_words')

    state = fields.Selection([
        ('draft', 'Quotation'),
        ('waiting_for_approval', 'Waiting For Quotation Approval'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True, copy=False, index=True, track_visibility='onchange', default='draft')
    sample_state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sample Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True, copy=False, index=True, track_visibility='onchange', default='draft')

    order_line = fields.One2many('sale.order.line', 'order_id', string='Order Lines',
                                 states={'cancel': [('readonly', True)], 'done': [('readonly', True)]},
                                 copy=True, auto_join=True, track_visibility='onchange')

    delivery_order_line = fields.One2many('stock.picking', 'sale_id', 'Delivery Order Status')
    delivery_status = fields.Selection(
        [('new', 'New'), ('nothing_delivery', 'Nothing For Delivery'), ('waiting_delivery', 'Waiting For Delivery'),
         ('return', 'Returned'),
         ('waiting_return', 'Waiting For Return'), ('nothing', 'Nothing To Return'), ('cancel', 'Cancelled')],
        compute='_compute_delivery_status', string="Status", default='new')

    @api.depends('delivery_order_line.state')
    def _compute_deliver_status(self):
        for rec in self:
            if not rec.order_line:
                rec.deliver_status = 'nothing_delivery'
            else:
                wait_del = rec.order_line.filtered(lambda x: x.product_uom_qty != x.qty_delivered)
                partially_del = rec.order_line.filtered(
                    lambda x: x.qty_delivered > 0 and not x.product_uom_qty == x.qty_delivered)
                fully_del = rec.order_line.filtered(lambda x: x.product_uom_qty == x.qty_delivered)

                if wait_del and not partially_del:
                    rec.deliver_status = 'waiting_delivery'
                if partially_del and not fully_del:
                    rec.deliver_status = 'partially_delivered'
                if fully_del:
                    rec.deliver_status = 'fully_delivered'

    deliver_status = fields.Selection(
        [('nothing_delivery', 'Nothing For Delivery'),
         ('waiting_delivery', 'Waiting For Delivery'),
         ('partially_delivered', 'Partially Delivered'),
         ('fully_delivered', 'Fully Delivered'), ('cancel', 'Cancelled')],
        compute='_compute_deliver_status', string="Delivery Status", default='nothing_delivery')
    return_status = fields.Selection(
        [('nothing_return', 'Nothing For Return'),
         ('waiting_return', 'Waiting For Return'),
         ('partially_returned', 'Partially Returned'),
         ('fully_returned', 'Fully Returned'), ('cancel', 'Cancelled')],
        compute='_compute_return_status', string="Return Status", default='nothing_return')

    @api.depends('delivery_order_line.state')
    def _compute_return_status(self):
        for rec in self:
            if not rec.order_line:
                rec.return_status = 'nothing_return'
            else:
                wait_del = rec.order_line.filtered(lambda x: x.qty_delivered > 0 and x.return_qty == 0)
                partially_del = rec.order_line.filtered(lambda x: x.pending_qty > 0.0 and x.return_qty > 0)
                fully_del = rec.order_line.filtered(
                    lambda x: x.return_qty == x.product_uom_qty and x.pending_qty == 0.0)
                if not wait_del and not partially_del and not wait_del:
                    rec.return_status = 'nothing_return'
                if wait_del and not partially_del:
                    rec.return_status = 'waiting_return'
                if partially_del and not fully_del:
                    rec.return_status = 'partially_returned'
                if fully_del:
                    rec.return_status = 'fully_returned'

    sale_amt = fields.Float(string='Total Sample Amount')
    sale_type = fields.Selection([
        ('sale', 'Sale'),
        ('sample_gift', 'Sample'),
        ('gift', 'Gift'),
        ('gcrm', 'GCRM'),
    ], string='Type')

    customisation = fields.Boolean('Customization Required')
    po_date = fields.Date('PO Received Date', track_visibility='onchange')
    po_number = fields.Char('PO Number', track_visibility='onchange')
    delivery_date = fields.Date('Delivery Date', track_visibility='onchange')
    penalty = fields.Selection([('yes', 'Yes'), ('no', 'No')], string='Penalty', track_visibility='onchange')
    po_attachment = fields.Binary('PO Attachment', track_visibility='onchange')
    # lead_id = fields.Many2one('crm.lead','Lead')
    need_approval = fields.Boolean(string='Need Approval')
    attachment_ids = fields.Many2many('ir.attachment', 'attachment_order_rel', 'sale_id', 'attachment_id',
                                      string='PO Attachment', track_visibility='onchange')
    # gift_amt = fields.Float('Gift/Sample Amt.')
    gift_amt = fields.Float('Gift/Sample Amt.')
    remaining_sale_amtount = fields.Float(copy=False, string='Remaining Sample Amount', track_visibility='onchange')
    packing_line = fields.One2many('packing.line', 'pack_order_id', copy=True)
    need_po_amendment = fields.Boolean('PO Attachment', track_visibility='onchange')
    purchase_lead = fields.Integer('Purchase Lead Time', track_visibility='onchange')
    packing_lead = fields.Integer('Packing Lead Time', track_visibility='onchange')
    shipping_lead = fields.Integer('Shipping Lead Time', track_visibility='onchange')
    delivery_lead = fields.Integer(compute='_compute_delivery_lead', string='Delivery Lead Time')
    remaining_days = fields.Integer(
        compute='_compute_remaining_days',
        string='Remaining Days to Delivery',
        store=True,
        copy=False
    )


    @api.depends('purchase_lead', 'packing_lead', 'shipping_lead')
    def _compute_delivery_lead(self):
        for sale in self:
            sale.delivery_lead = sale.purchase_lead + sale.packing_lead + sale.shipping_lead


    packing_done_days = fields.Float('Packing Confirmation Days', readonly=True, track_visibility='onchange')
    shiping_day = fields.Integer('Shipping Day', track_visibility='onchange')
    consume_sample_amt = fields.Float(copy=False, string='Consumed Sample Amount', store=True,
                                      compute='_compute_user_id_amt')
    kit_product_line = fields.One2many('order.pack.product', 'order_kit_id', compute="_product_packing_order",
                                       readonly=False, store=True)
    pack_design_id = fields.Many2one('package.design', string="Designing Reference", track_visibility='onchange')
    sent_for_design = fields.Boolean('Sent For Design', track_visibility='onchange')
    design_states = fields.Selection([('new', 'New'),
                                      ('design_submit', 'Design Submitted'),
                                      ('customer_approve', 'Customer Approved'),
                                      ('done', 'Done'),
                                      ('cancel', 'Cancel')], compute="_design_states")
    date_need_approval = fields.Boolean()
    email_attachment_ids = fields.Many2many('ir.attachment', 'order_attachment_rel', 'sale_id', 'attachment_id',
                                            string='Email Attachment', track_visibility='onchange')
    packaging_total = fields.Float(compute="total_packaging_amount", string="Total Amount", store=True)
    # sample_amount_total = fields.Float(compute="_sample_amtount",store=True)
    sap_code = fields.Char('Sap Code')
    rm_name = fields.Char('RM Name')
    region = fields.Char('Region')
    gcrm_no = fields.Char('GCRM No.')
    requisition_from = fields.Char('Requisition From')
    requisition_date = fields.Date('Requisition Date')
    division_id = fields.Many2one('division', 'Division')
    # punch_by = fields.Char('Punch By')
    dr_name = fields.Char('Dr Name')
    delivery_address = fields.Char('Delivery Address')
    courier_no = fields.Char('Courier No.')
    courier_name = fields.Char('Courier Name')
    inv_date = fields.Date('Invoice Date')
    inv_number = fields.Char('Invoice Number')
    is_msp_approval = fields.Boolean()
    packaging_po_id = fields.Many2one('purchase.order')
    target_amount = fields.Float(related='user_id.sale_target', string='Target Amount',
                                 readonly=True)
    brand_ids = fields.Many2many('brand', 'brand_sale_rel', 'sale_id', 'brand_id', 'Brand', track_visibility='onchange')

    @api.depends('order_line')
    def _product_packing_order(self):
        if self.order_line:
            package_list = []
            kit_obj = self.env['order.pack.product']
            for line in self.order_line:
                bom = self.env['mrp.bom'].search([('product_tmpl_id', '=', line.product_id.product_tmpl_id.id)])
                if bom:
                    for bom_comp in bom.bom_line_ids:
                        package_list.append((0, 0, {
                            'order_kit_id': self.id,
                            'product_id': bom_comp.product_id.id,
                            'kit_product_id': line.product_id.id,
                            'qty': line.product_uom_qty * bom_comp.product_qty,
                            'kit_qty': bom_comp.product_qty,
                            # 'tax_id': [(6,0, line.tax_id.ids)],
                            'hsn_id': bom_comp.product_id.hsn_code,
                            'sale_price': bom_comp.product_id.product_tmpl_id.list_price,
                            'unit_price': bom_comp.product_id.product_tmpl_id.standard_price,
                            'forecost_qty': bom_comp.product_id.virtual_available
                        }))
                    self.kit_product_line = package_list
                    line.is_kit = True

    @api.depends('user_id')
    def _compute_user_id_amt(self):
        """
        @api.depends() should contain all fields that will be used in the calculations.
        """
        if self.user_id:
            self.consume_sample_amt = self.user_id.used_sale_amt

    packaging_state = fields.Selection([
        ('draft', 'RFQ'),
        ('sent', 'RFQ Sent'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ], string='Packaging Status', readonly=True, index=True, copy=False, compute="packaging_po", store=True)

    achieved_amt = fields.Float('Achieved Amount', compute="compute_order_amount")
    exporters_ref = fields.Char("Exporters Ref")
    buyer_order_no = fields.Char("Buyers Order No.")
    pre_carriage_by = fields.Char("Pre Carriage By")
    place_of_receipt = fields.Char("Place Of Receipt By Pr-Carrier")
    vessel_flight_no = fields.Char("Vessel/Flight NO.")
    port_of_loading = fields.Char("Port Of Loading")
    port_of_dise = fields.Char("Port Of Dise")
    final_destn = fields.Char("Final Dest.")
    terms_of_payments = fields.Char("Terms Of Delivery Of Payments")
    marks_no = fields.Char("Marks & No.")
    kind_of_pkgs = fields.Char("No & Kind Of Pkgs.")
    des_of_goods = fields.Char("Des.Of Goods")
    container_no = fields.Char("Container No.")
    origin = fields.Char("Origin")
    destination = fields.Char("Destination")
    book_no = fields.Char('Book Number')
    po_receipt_date = fields.Date('PO Receipt Date')
    submitted_date = fields.Date('Submitted Date')
    submitted_to = fields.Char('Submitted To')
    artwork_need = fields.Boolean('Artwork Required')
    product_amt_total = fields.Float('Total', compute="compute_total_product_cost", store=True)
    cgst_total = fields.Float('Output CGST', compute="compute_total", store=True)
    sgst_total = fields.Float('Output SGST', compute="compute_total", store=True)
    igst_total = fields.Float('Output IGST', compute="compute_total", store=True)
    design_attchment_ids = fields.Many2many('ir.attachment', 'attachment_sal_design_rel', 'sale_id', 'attachment_id',
                                            string='Design Attachment', track_visibility='onchange')
    segment_id = fields.Many2one('segment', 'Segment')
    approved_id = fields.Many2one('res.users', 'Approved by')
    requested_id = fields.Many2one('res.users', 'Requested for Approval')
    design_requested_id = fields.Many2one('res.users', 'Design Requested To')
    packaging_req_id = fields.Many2one('res.users', 'Packaging Requested To')
    # reject_reason_line = fields.One2many('reason.line', 'reason_id', track_visibility='onchange')

    @api.depends('user_id', 'state')
    def compute_order_amount(self):
        current_date = datetime.now().date()
        range = calendar.monthrange(current_date.year, current_date.month)
        start_date = date(current_date.year, current_date.month, 1)
        end_date = date(current_date.year, current_date.month, range[1])
        for order in self:
            self.env.cr.execute("""
                   SELECT sum(amount_untaxed) from sale_order where
                   date_order >= %s
                   and date_order <= %s
                   and sale_type = 'sale'
                   and state in ('sale','done')
                   and user_id = %s
               """, (start_date, end_date, order.user_id.id))
            result = self._cr.fetchall()
            if result:
                order.achieved_amt = result[0][0]

    convert_to_gift = fields.Boolean('Converted')
    gift_convert_approved = fields.Boolean('Approved')
    gift_rejected = fields.Boolean('Rejected')
    is_kit = fields.Boolean('Is Kit?')
    is_existing_kit = fields.Boolean('Is Existing Kit?')
    kit_id = fields.Many2one('product.product', 'Kit')
    kit_name = fields.Char('Kit Name')
    kit_quantity = fields.Integer('Kit Quantity', default=0)
    delivery_schedule = fields.Selection([
        ('immidiate', 'Immediate'),
        ('7days', '7 Days'),
        ('15days', '15 Days'),
        ('4-6', '4 to 6 Weeks'),
        ('6-8', '6 to 8 Weeks'),
        ('8-10', '8 to 10 Weeks'),
        ('10-Above', '10 Weeks & Above')
    ], string='Delivery Schedule', copy=False, index=True)
    kit_rate = fields.Monetary(string='Kit Rate (Per Qty)', store=True, readonly=True, compute='_amount_all_kit',
                               track_visibility='onchange')
    kit_rate_total = fields.Monetary(string='Total Kit Rate', store=True, readonly=True, compute='_amount_kit',
                                     track_visibility='onchange')
    kit_rate_grandtotal = fields.Monetary(string='Total', store=True, readonly=True, compute='_amount_kit_total',
                                          track_visibility='onchange')
    kit_product = fields.Many2one('product.product', 'Kit Product', copy=False, index=True)
    picking_type_mo = fields.Many2one(
        'stock.picking.type',
        string='Kit Manufacturing Location',
        copy=False,
        index=True
    )
    internal_transfer_mo = fields.Many2one(
        'stock.picking',
        string='Transfer to Process',
        copy=False,
        index=True
    )
    partner_ids = fields.Many2many(
        'res.partner',
        'rel_sale_partner_invoice',
        'sale_id',
        'partner_id',
        string='Associated Addresses',
    )

    parent_ids = fields.Many2many(
        'res.partner',
        'rel_sale_parent',
        'sale_order_id',
        'parent_id',
        string='Associated Parent Addresses',
    )
    count_purchase_order = fields.Integer(compute='_count_purchase_order', string='Purchase Count')
    requisition_count = fields.Integer(compute='_count_requisition', string='Requisition Count')
    logged_in_user = fields.Many2one('res.users', compute='_get_user', string='Logged in User')
    is_packaging_team = fields.Boolean(
        string='Is Packaging Team', copy=False,
        index=True)
    is_sales_team = fields.Boolean(
        string='Is Sales Team', copy=False,
        index=True)
    sent_to_customer = fields.Boolean(
        string='Sent to Customer', copy=False,
        index=True, default=False)
    bom_id = fields.Many2one('mrp.bom', string='Kit BOM', copy=False, index=True, readonly=True)
    manufacturing_id = fields.Many2one('mrp.production', string='MO Reference', copy=False, index=True, readonly=True)
    salesperson_name = fields.Char(
        related='user_id.name', string='Salesperson',
        copy=False, index=True, readonly=True, store=True
    )
    minimum_tax_kit = fields.Many2one(
        'account.tax',
        string='Taxes',
        copy=False, index=True, readonly=True, store=True
    )
    tax_kit = fields.Char(
        string='Taxes', compute='_get_max_tax',
        copy=False, index=True
    )
    user_id = fields.Many2one('res.users', string='Salesperson', index=True, track_visibility='onchange')
    kit_igst = fields.Monetary(string='Output IGST')
    kit_sgst = fields.Monetary(string='Output SGST')
    kit_cgst = fields.Monetary(string='Output CGST')
    is_quotation_sent = fields.Boolean(
        string='Quotation Sent for Approval', copy=False,
        index=True, default=False)
    is_quotation_approved = fields.Boolean(
        string='Quotation Approved', copy=False,
        index=True, default=False)
    is_quotation_rejected = fields.Boolean(
        string='Quotation Rejected', copy=False,
        index=True, default=False)
    is_msp_custom_combo = fields.Boolean(compute='_get_combo_value',
                                         string='Both True', copy=False,
                                         index=True, default=False, store=True)

    related_sale_ids = fields.Many2many('sale.order', 'related_sale_order_rel', 'sale_id',
                                        'sale_id2', string='Related Orders',
                                        help='Used for reports in case of confirmed in bulk')
    customization_igst = fields.Monetary(string='Output IGST', compute='_get_customization_tax', store=True)
    customization_sgst = fields.Monetary(string='Output SGST', compute='_get_customization_tax', store=True)
    customization_cgst = fields.Monetary(string='Output CGST', compute='_get_customization_tax')
    tax_customisation = fields.Char(
        string='HSN Code', compute='_get_customization_tax',
        copy=False, index=True
    )
    cutomisation_taxes = fields.Char(
        string='Taxes', compute='_get_customization_tax',
        copy=False, index=True
    )
    amount_untaxed_customization = fields.Monetary(
        string='Untaxed Amount', store=True, readonly=True, compute='_amount_all_customization',
        track_visibility='onchange')
    amount_customization_total = fields.Monetary(
        string='Total Amount', store=True, readonly=True, compute='_amount_customization_total',
        track_visibility='onchange')
    is_old_order = fields.Boolean(
        string='Old Order', copy=False, default=False,
    )

    @api.onchange('is_old_order')
    def chnage_old_order(self):
        for data in self:
            if data.is_old_order:
                data.customisation = False


    @api.depends('is_msp_approval', 'customisation')
    def _get_combo_value(self):
        for data in self:
            if data.is_msp_approval is True and data.customisation is True:
                data.is_msp_custom_combo = True

            else:
                data.is_msp_custom_combo = False

    @api.onchange('is_kit')
    def change_is_kit(self):
        for data in self:
            warehouse_id = self.env['stock.warehouse'].search([('company_id', '=', self.company_id.id)])
            # data.picking_type_mo = warehouse_id


    @api.constrains('kit_quantity', 'is_kit')
    def _check_kit_quantity(self):
        for order in self:
            if order.is_kit and order.kit_quantity <= 0:
                raise UserError(_('Validation Error !\nKit quantity should be greater than 0 !'))
        return True

    @api.depends('purchase_lead', 'packing_lead', 'shipping_lead')
    def _compute_delivery_lead(self):
        for sale in self:
            sale.delivery_lead = sale.purchase_lead + sale.packing_lead + sale.shipping_lead

    @api.onchange('is_kit', 'is_existing_kit')
    def _onchange_existing_kit(self):
        if self.is_kit and not self.is_existing_kit:
            self.kit_id = False
            self.order_line = []

    @api.onchange('kit_quantity')
    def _onchange_kit_quantity(self):
        if self.is_kit and self.order_line:
            for line in self.order_line:
                line.product_uom_qty = line.qty_per_kit

    @api.depends('order_line.tax_id')
    def compute_total(self):
        for rec in self:
            cgst = sgst = igst = 0.0
            for tax in rec.order_line:
                cgst = cgst + tax.cgst
                sgst = sgst + tax.sgst
                igst = igst + tax.igst
            rec.cgst_total = cgst
            rec.sgst_total = sgst
            rec.igst_total = igst



    @api.depends('order_line.product_id')
    def compute_total_product_cost(self):
        total = 0.0
        for rec in self:
            for line in rec.order_line:
                if line.product_id:
                    total = total + (line.product_id.standard_price * line.product_uom_qty)
            rec.product_amt_total = total
            total = 0.0

    def create_kit(self):
        exist_kit = self.env['product.product'].sudo().search([('name', '=', self.kit_name)])
        if exist_kit:
            raise UserError(_('Warning! \n \n Kit name %s%s%s already exist. \n Please use different name for Kit!' %("'", self.kit_name, "'")))
        kit = self.env['product.product'].sudo().create({
            'name': self.kit_name or '',
            'standard_price': self.kit_rate,
            'type': 'product',
            'tracking': 'lot',
            'invoice_policy': 'delivery',
            'uom_id': self.env.ref('product.product_uom_unit').id,
            'uom_po_id': self.env.ref('product.product_uom_unit').id,
            'categ_id': self.env.ref('product.product_category_1').id,
            'service_type': 'manual',
            'taxes_id': False,
            'is_kit': True,
        })
        self.kit_product = kit.id
        self.create_bom(kit)


    def create_bom(self, kit):
        bom_dict = {
            'product_id': kit.id,
            'product_tmpl_id': kit.product_tmpl_id.id,
            'product_qty': 1,
            'product_uom_id': kit.uom_id.id,
            'type': 'normal',
        }
        bom_line_dict = []
        for line in self.order_line:
            bom_line_dict.append((0, 0, {
                'product_id': line.product_id.id,
                'product_qty': line.qty_per_kit,
            }))
        bom_dict['bom_line_ids'] = bom_line_dict
        bom = self.env['mrp.bom'].sudo().create(bom_dict)
        self.bom_id = bom.id

    def view_kit(self):
        '''
        This function returns an action that display related kit of current sales order.'''
        action = self.env.ref('product.product_template_action_all').read()[0]
        if self.kit_id:
            action['views'] = [(self.env.ref('product.product_template_only_form_view').id, 'form')]
            action['res_id'] = self.kit_id.product_tmpl_id.id
        return action

    def conv(self, val):
        return num2words(val)

    @api.model
    def default_get(self, default_fields):
        data = super(SaleOrder, self).default_get(default_fields)
        context = dict(self._context or {})
        active_ids = context.get('active_ids', []) or []
        product_lst = []
        if self.env.context.get('active_model') == 'product.template':
            products = self.env['product.template'].browse(active_ids)
            if products:
                for record in products:
                    product_lst.append((0, 0, {
                        'product_id': record.id,
                        'product_uom_qty': 1,
                        'price_unit': record.list_price,
                        'name': record.name,
                        'product_uom': record.uom_id.id,
                        'return_status': 'new'
                    }))
                data['order_line'] = product_lst
        return data

    def action_confirm(self):
        if not self.order_line:
            raise UserError(_('Please Add Order Lines !!!'))

        if self.sale_type in ('sample_gift','display'):
            for line in self.order_line:
                line.return_status = 'waiting_delivery'
        if self.sale_type == 'gcrm' and not self.inv_number:
            raise UserError(_('Please enter action_confirmce number first !'))
        if self.sale_type == 'sale':
            design_group = self.env.ref('gts_qms_sale_order.group_design_packing')
            email_to = ' '
            for user in design_group.sudo().users:
                email_to = email_to + user.partner_id.email + ','


            msg = ''
            if not self.po_date:
                msg += 'PO Received Date, '
            if not self.po_receipt_date:
                msg += 'PO Date, '
            if not self.po_number:
                msg += 'PO Number, '
            if not self.delivery_date:
                msg += 'PO Delivery Date, '
            if not self.attachment_ids:
                msg += 'PO Attachment'
            if not self.po_date or not self.delivery_date or not self.po_number or not self.attachment_ids:
                raise UserError(_('Please Fill PO Details : %s' %(msg)))

            number = ''


        if self.user_id:
            if self.user_id.is_salesperson:
                if self.sale_type == 'sample_gift':
                   self.sudo().user_id.used_sale_amt = self.sudo().user_id.used_sale_amt + self.sudo().amount_untaxed

        if self.sale_type == 'sample_gift':
            self.write({'sample_state': 'sale'})
         # notification mail to purchase against SO
        if self.sale_type == 'sale':
            line_lst = []
            kit_lst = []
            # NEHA: Update user group
            # purchase_group = self.env.ref('purchase.group_purchase_manager')
            purchase_group = self.env.ref('gts_qms_sale_order.group_product_procurement_team')
            email_to = ' '
            # NEHA: Update to send mail one at a time
            # for user in purchase_group.sudo().users:
            #     email_to = email_to + user.partner_id.email + ','
            for line in self.order_line:
                if line.is_kit is False:
                    if line.virtual_available < line.product_uom_qty or line.virtual_available < 0.0:
                        line_lst.append(line.id)
            if self.kit_product_line:
                for kit in self.kit_product_line:
                    if kit.product_available_qty < 0.0 or kit.product_available_qty < kit.qty:
                        kit_lst.append(kit.id)
        # if self.sale_type == 'sale':
        if self.is_kit:
            kit_ = self.create_kit()
        res = super(SaleOrder, self).action_confirm()
        # For sending confirmation email to Order Confirmation GROUP
        if self.sale_type in ('sample_gift', 'gift', 'display'):
            self.action_order_confirmation_mail()
        if self.sale_type == 'sale':
            if self.is_kit:
                mo_search_id = self.env['mrp.production'].search([('origin', '=', self.name)])

                self.manufacturing_id = mo_search_id.id
        return res

    @api.constrains('po_number')
    def _identify_same_po_number(self):
        for record in self:
            obj = self.search([
                ('po_number', '=ilike', record.po_number),
                ('id', '!=', record.id)
            ])
            if obj:
                raise ValidationError(
                    "PO Number already exist")

    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            if vals.get('sale_type') == 'sale':
                if 'company_id' in vals:
                    vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                        'sale.order') or _('New')
                else:
                    vals['name'] = self.env['ir.sequence'].next_by_code('sale.order') or _('New')
            if vals.get('sale_type') == 'sample_gift':
                sequence = self.env.ref('gts_qms_sale_order.sample_gift_sequence')
                seq = sequence.next_by_id()
                vals['name'] = seq or '/'
            if vals.get('sale_type') == 'gcrm':
                sequence = self.env.ref('gts_qms_sale_order.gcrm_sequence')
                seq = sequence.next_by_id()
                vals['name'] = seq or '/'
            if vals.get('sale_type') == 'display':
                sequence = self.env.ref('gts_qms_sale_order.display_sequence')
                seq = sequence.next_by_id()
                vals['name'] = seq or '/'
            if vals.get('sale_type') == 'gift':
                sequence = self.env.ref('gts_qms_sale_order.gift_sequence')
                seq = sequence.next_by_id()
                vals['name'] = seq or '/'

        if vals.get('is_kit') and vals.get('kit_quantity') <= 0:
            raise ValidationError(_('Kit quantity should be greater than 0 !'))
        # Makes sure partner_invoice_id', 'partner_shipping_id' and 'pricelist_id' are defined
        if any(f not in vals for f in ['partner_invoice_id', 'partner_shipping_id', 'pricelist_id']):
            partner = self.env['res.partner'].browse(vals.get('partner_id'))
            addr = partner.address_get(['delivery', 'invoice'])
            vals['partner_invoice_id'] = vals.setdefault('partner_invoice_id', addr['invoice'])
            vals['partner_shipping_id'] = vals.setdefault('partner_shipping_id', addr['delivery'])
            vals['pricelist_id'] = vals.setdefault('pricelist_id',
                                                   partner.property_product_pricelist and partner.property_product_pricelist.id)
        result = super(SaleOrder, self).create(vals)
        # NEHA : for products logs
        if 'order_line' in vals:
            pro_list = []
            for line in vals.get('order_line'):
                pro_list.append(line[2].get('name'))
            print('pro_list', pro_list)
            message = "Products : %s" % (",  ".join(pro_list))
            result.message_post(body=message)
        return result

    def write(self, vals):
        res = super(SaleOrder, self).write(vals)
        if self.is_kit and self.kit_quantity <= 0:
            raise ValidationError(_('Kit quantity should be greater than 0 !'))
        pro_list = []
        # NEHA : for products logs
        if 'order_line' in vals:
            for line in vals.get('order_line'):
                if not line[2] == False and line[2].get('name'):
                    pro_list.append(line[2].get('name'))
            if pro_list:
                message = " Products : %s" % (", ".join(pro_list))
                self.message_post(body=message)
        return res

    def action_draft(self):
        res = super(SaleOrder, self).action_draft()
        self.sent_to_customer = False
        if self.sale_type == 'sample_gift':
            self.write({'sample_state': 'draft'})

    def action_cancel(self):
        res = super(SaleOrder, self).action_cancel()
        if self.amount_untaxed > self.user_id.sale_amount:
            self.write({ 'is_sample_sent': False})
        if any(data.price_unit < data.msp for data in self.order_line):
            self.write({'is_msp_approval': True, 'is_quotation_sent': False})
        if self.remaining_days < 0 or self.delivery_lead > self.remaining_days:
            self.write({
                'is_so_approval': False,
                'is_so_approved': False,
                'is_so_sent': False,
                'po_receipt_date': False,
                'delivery_date': False,
                'po_date': False,
        })
        update_amt = 0.0
        if self.sale_type == 'sample_gift':
            self.write({'sample_state': 'cancel'})
            self.write({'delivery_status': 'cancel', 'deliver_status': 'cancel'})
            for line in self.order_line:
                line.return_status = 'cancel'
        if self.delivery_order_line and self.sale_type == 'sample_gift':
            if self.sudo().user_id:
                for line in self.order_line:
                    if line.type == 'sample':
                        update_amt = line.sudo().order_id.user_id.used_sale_amt - line.price_subtotal
                        self.sudo().user_id.write({'used_sale_amt': update_amt})
                        update_amt =0.0
        return res

    def action_unlock(self):
        res = super(SaleOrder, self).action_unlock()
        if self.sale_type == 'sample_gift':
            self.write({'sample_state': 'sale'})
        return res


    def action_done(self):
        res = super(SaleOrder, self).action_done()
        if self.sale_type == 'sample_gift':
            self.write({'sample_state': 'done'})
        return res

    @api.depends('order_line')
    def _product_packing_order(self):
        if self.order_line:
            package_list = []
            kit_obj = self.env['order.pack.product']
            for line in self.order_line:
                bom = self.env['mrp.bom'].search([('product_tmpl_id', '=', line.product_id.product_tmpl_id.id)])
                if bom:
                    for bom_comp in bom.bom_line_ids:
                        package_list.append((0, 0, {
                            'order_kit_id': self.id,
                            'product_id': bom_comp.product_id.id,
                            'kit_product_id': line.product_id.id,
                            'qty': line.product_uom_qty * bom_comp.product_qty,
                            'kit_qty': bom_comp.product_qty,
                            # 'tax_id': [(6,0, line.tax_id.ids)],
                            'hsn_id': bom_comp.product_id.hsn_code,
                            'sale_price': bom_comp.product_id.product_tmpl_id.list_price,
                            'unit_price': bom_comp.product_id.product_tmpl_id.standard_price,
                            'forecost_qty': bom_comp.product_id.virtual_available
                        }))
                    self.kit_product_line = package_list
                    line.is_kit = True

class KitProductLine(models.Model):
    _name = 'order.pack.product'

    @api.depends('qty','unit_price')
    def _price_subtotal(self):
        for line in self:
            line.subtotal = line.qty * line.sale_price

    order_kit_id = fields.Many2one('sale.order')
    product_uom = fields.Many2one('product.uom', string='Unit of Measure')
    kit_qty = fields.Float('Qty/Kit')
    product_id = fields.Many2one('product.product','Product')
    kit_product_id = fields.Many2one('product.product','Kit Name')
    qty = fields.Float('Quantity')
    unit_price = fields.Float('MRP')
    hsn_id = fields.Many2one('hsn.master','HSN Code', compute="product_change")
    tax_id = fields.Many2many('account.tax','pack_tax_rel','pack_id','tax_id', 'Tax',compute="product_change")
    cgst = fields.Float(string='CGST', compute='_compute_gst', store=True, digits=dp.get_precision('Product Price'))
    sgst = fields.Float(string='SGST', compute='_compute_gst', digits=dp.get_precision('Product Price'))
    igst = fields.Float(string='IGST', compute='_compute_gst', digits=dp.get_precision('Product Price'))
    amount = fields.Float(string='Amt. with Taxes', readonly=True, compute='_compute_gst',
                          digits=dp.get_precision('Product Price'))
    sale_price = fields.Float('Offer Price/Product')
    discount = fields.Float('Discount')
    forecost_qty = fields.Float('Forecasted Qty')
    product_available_qty = fields.Float(compute="_available_qty",string='Available Qty',store=True)
    subtotal = fields.Float('Subtotal',compute="_price_subtotal", store=True)
    company_id = fields.Many2one('res.company', 'Company',
                                 default=lambda self: self.env['res.company']._company_default_get('package.design'))
    qty_available = fields.Float(compute="_available_qty",string='Available quantity')

    def product_change(self):
        for line in self:
            if not line.product_id:
                return True
            if line.product_id.hsn_code:
                branch_state = line.order_kit_id.company_id.state_id
                partner_state = line.order_kit_id.partner_id.state_id
                invoice_addres_id = line.order_kit_id.partner_invoice_id.state_id
                sale_tax = []
                sale_tax2 = []
                line.hsn_id = line.product_id.hsn_code and line.product_id.hsn_code.id
                if line.product_id.hsn_code:
                    hsn_code = line.product_id.hsn_code
                    if invoice_addres_id:
                        if branch_state == invoice_addres_id:
                            sale_tax.append(hsn_code.cgst_sale.id)
                            sale_tax.append(hsn_code.sgst_sale.id)
                            line.tax_id = sale_tax
                        else:
                            sale_tax2.append(hsn_code.igst_sale.id)
                            line.tax_id = sale_tax2
                    if not invoice_addres_id:
                        if branch_state == partner_state:
                            sale_tax.append(hsn_code.cgst_sale.id)
                            sale_tax.append(hsn_code.sgst_sale.id)
                            line.tax_id = sale_tax
                        else:
                            sale_tax2.append(hsn_code.igst_sale.id)
                            line.tax_id = sale_tax2

    @api.depends('sale_price', 'qty', 'tax_id.tax_type', 'tax_id.type_tax_use', 'discount')
    def _compute_gst(self):
        cgst_rate = 0
        sgst_rate = 0
        igst_rate = 0
        for rec in self:
            cgst_total = 0
            sgst_total = 0
            igst_total = 0
            for line in rec.tax_id:
                if line.tax_type == 'cgst' and line.type_tax_use == 'sale':
                    cgst_total = cgst_total + line.amount
                if line.tax_type == 'sgst' and line.type_tax_use == 'sale':
                    sgst_total = sgst_total + line.amount
                if line.tax_type == 'igst' and line.type_tax_use == 'sale':
                    igst_total = igst_total + line.amount
                cgst_rate = cgst_total / 100
                sgst_rate = sgst_total / 100
                igst_rate = igst_total / 100
            base = rec.sale_price * (1 - (rec.discount or 0.0) / 100.0)
            rec.cgst = (base * rec.qty) * cgst_rate
            rec.sgst = (base * rec.qty) * sgst_rate
            rec.igst = (base * rec.qty) * igst_rate
            rec.amount = (base * rec.qty) + rec.cgst + rec.sgst + rec.igst

    @api.depends('product_id')
    def _available_qty(self):
        stock_loc = self.env['stock.location'].search([('name', '=', 'Stock')], limit=1)
        for line in self:
            line.product_available_qty = line.product_id.with_context(location=stock_loc.id).virtual_available
            line.qty_available = line.product_id.with_context(location=stock_loc.id).qty_available


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'


    def _compute_return_amt(self):
        picking = self.env['stock.picking']
        for rec in self:
            if rec.order_id.sale_type == 'sample_gift':
                if rec.order_id.user_id.is_salesperson:
                    if rec.state == 'done' or rec.state == 'sale':
                        if rec.return_amount == 0.0:
                            picking_id = picking.search([('sale_id', '=', rec.order_id.id),
                                                         ('state', '=', 'done')])
                            if picking_id:
                                # NEHA: add loop for picking multiple values
                                for pic in picking_id:
                                    if pic.amount_returned == False:
                                        for line in pic.move_lines:
                                            if line.sale_line_id.type == 'sample':
                                                line.sale_line_id.return_amount = line.quantity_done * line.sale_line_id.price_unit
                                                line.sale_line_id.write({'return_status': 'return','returned_date': fields.Datetime.now()})
                                                rec.order_id.sudo().user_id.write({
                                                                                    'used_sale_amt': rec.order_id.user_id.used_sale_amt - rec.return_amount})
                                                picking_id.write({'amount_returned': True})
                                                return_amount = 0.0

    location_type = fields.Selection(string="Location Type",
                                     selection=[('from_sample', 'From Sample'),
                                                ('from_stock', 'From Stock'), ], required=False, )

    type = fields.Selection([('sample', 'Sample'), ('gift', 'Gift'), ('pending', 'Pending')], default="sample",
                            string='Type')
    gift_qty = fields.Integer('Gift Quantity', default=0)
    line_status = fields.Selection(
        [('need_approval', 'Need Approval'), ('approved', 'Approved'), ('rejected', 'Rejected')], default='approved',
        string='Status')
    return_amount = fields.Float(compute="_compute_return_amt", string='Return Amt')
    date_order = fields.Datetime(related='order_id.date_order', store=True, string="System Date")
    sample_confirm_date = fields.Date('Sample Date')
    partner_id = fields.Many2one(related='order_id.partner_id', store=True)
    partner_company_id = fields.Many2one('res.partner', compute="partner_company", store=True, string='Organization')
    # division_ids = fields.Many2many(related="order_id.partner_id.division_ids")
    # product_status = fields.Selection([('returnable','Returnable'),('non-')])
    return_status = fields.Selection(
        [('new', 'New'), ('return', 'Returned'),
         ('nothing', 'Nothing To Return'),
         ('waiting_return', 'Waiting For Return'),
         ('cancel', 'Cancelled')], string="Status", default='new')
    sample_punched_id = fields.Many2one('res.users', default=lambda self: self.env.user, string="Sample punched by")
    allotment_date = fields.Date(string='Allotment Date')
    returned_date = fields.Date('Returned Date')
    lot_ids = fields.Many2many('stock.production.lot', 'lot_line_ref', 'line_id', 'lot_id', string='Lot')
    remarks = fields.Char('Remarks')
    virtual_available = fields.Float(compute="_compute_qty_location", string='Forecasted quantity')
    qty_available = fields.Float(compute="_compute_qty_location", string='Available quantity')
    return_qty = fields.Float('Return Qty', default=0.0)
    cost_price = fields.Float(related='product_id.product_tmpl_id.standard_price', string='Purchase  value  pre GST')
    attach_slide = fields.Boolean('Attach Slide?')
    pending_qty = fields.Float('Pending Qty', compute="compute_pending_qty", store=True, default=0.0)
    is_kit = fields.Boolean(default=False)
    msp = fields.Float('MSP')
    product_id = fields.Many2one('product.product', string='Product', domain=[('sale_ok', '=', True)],
                                 change_default=True, ondelete='restrict', required=True, track_visibility='onchange')
    qty_per_kit = fields.Integer('Qty/Kit', default=0)

    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_id')
    def _compute_amount(self):
        """
        Compute the amounts of the SO line.
        """
        for line in self:
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            taxes = line.tax_id.compute_all(price, line.order_id.currency_id, line.product_uom_qty,
                                            product=line.product_id, partner=line.order_id.partner_shipping_id)
            line.update({
                'price_tax': sum(t.get('amount', 0.0) for t in taxes.get('taxes', [])),
                'price_total': taxes['total_included'],
                'price_subtotal': taxes['total_excluded'],
            })

    def _compute_qty_location(self):
        stock_loc = self.env['stock.location'].search([('name', 'ilike', 'Stock')])
        sample_loc = self.env['stock.location'].search([('name', '=', 'Sample Location')], limit=1)
        for line in self:
            if line.order_id.sale_type == 'sale':
                line.virtual_available = line.product_id.with_context(location=stock_loc.ids).virtual_available
                line.qty_available = line.product_id.with_context(location=stock_loc.ids).qty_available
            if line.order_id.sale_type == 'sample_gift' or line.order_id.sale_type == 'display':
                line.virtual_available = line.product_id.with_context(location=sample_loc.id).virtual_available
                line.qty_available = line.product_id.with_context(location=sample_loc.id).qty_available

    @api.depends('return_qty', 'product_uom_qty', 'qty_delivered', 'order_id.gift_convert_approved')
    def compute_pending_qty(self):
        for line in self:
            if line.qty_delivered > 0.0:
                line.pending_qty = line.product_uom_qty - line.return_qty
                if line.order_id.gift_convert_approved is True:
                    line.pending_qty = line.product_uom_qty - line.return_qty - line.gift_qty

    @api.depends('partner_id')
    def partner_company(self):
        for rec in self:
            if rec.partner_id.parent_id:
                rec.partner_company_id = rec.partner_id.parent_id.id
            else:
                rec.partner_company_id = rec.partner_id.id



class PackingLine(models.Model):
    _name = 'packing.line'

    pack_order_id = fields.Many2one('sale.order')
    product_id = fields.Many2one('product.product','Customization Name')
    customize_name = fields.Char('Customization Name')
    type = fields.Char('Type')
    size = fields.Char('Size')
    price = fields.Float('Cost To Us/Piece')
    description = fields.Char('Description')
    quantity = fields.Integer('Quantity', default=0)
    total = fields.Float(compute="_compute_total",string='Total',store=True)
    company_id = fields.Many2one('res.company', 'Company',
                                 default=lambda self: self.env['res.company']._company_default_get('package.design'))




    def _prepare_purchase_order_line_packing(self, name, product_qty=0.0, price_unit=0.0, taxes_ids=False):
        self.ensure_one()
        sale = self.pack_order_id
        return {
            'name': name,
            'product_id': self.product_id.id,
            'product_uom': self.product_id.uom_po_id.id,
            'product_qty': product_qty,
            'price_unit': price_unit,
            'taxes_id': [(6, 0, taxes_ids)],
            'date_planned': fields.Date.today(),
            # 'account_analytic_id': self.account_analytic_id.id,
            # 'move_dest_ids': self.move_dest_id and [(4, self.move_dest_id.id)] or []
        }

    @api.depends('quantity', 'price')
    def _compute_total(self):
        for line in self:
            line.total = line.quantity * line.price

    @api.onchange('product_id')
    def product_id_change(self):
        for line in self:
            line.description = line.product_id.name