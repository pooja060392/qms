
from odoo import fields, models

class Company(models.Model):
    _inherit = 'res.company'



    pan = fields.Char("Pan Number")
    drug_lic_number = fields.Char("Drug License Number")
    fax_number = fields.Char("Fax Number")